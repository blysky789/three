from environs import Env
from dataclasses import dataclass


@dataclass
class Bots:
    mybot_token: str
    admin_id: int
    api_id: int
    api_hash: str
    # mypay_token: str

@dataclass
class Settings:
    bots: Bots

def get_settings(path: str):
    env = Env()
    env.read_env(path)

    return Settings(
        bots = Bots(
            mybot_token = env.str('api_token'),
            admin_id = env.int('admin_id'),
            api_id = env.int('api_id'),
            api_hash = env.str('api_hash')
            # mypay_token = env.str('pay_token')
        )
    )

settings = get_settings('input')
print(settings)
